export default 'WebCryptoAPI';
